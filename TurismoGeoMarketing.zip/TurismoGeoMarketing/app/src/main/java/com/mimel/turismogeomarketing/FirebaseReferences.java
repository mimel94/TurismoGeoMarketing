package com.mimel.turismogeomarketing;

public class FirebaseReferences {

    final public static String TURISMO = "turismogeomarketing";
    final public static String USER = "user";
    final public static String PLACES = "places";
    final public static String CITY = "city";
    final public static String PAYMENT_METHOD = "paymentMethod";
    final public static String TYPE_PLACE = "typePlace";

}
